/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include<stdio.h>
#include<math.h>

void main()
{
	float side1, side2, side3, area, s;
	
	printf("Enter the three sides of triangle\n");
	
	printf("Side 1:\t");
	scanf("%f", &side1);
	
	printf("Side 2:\t");
	scanf("%f", &side2);
	
	printf("Side 3:\t");
	scanf("%f", &side3);

	s = (side1 + side2 + side3) / 2;
	area = sqrt(s * (s - side1) * (s - side2) * (s - side3));

	printf("Area of the triangle is: %f\n", area);
}